# Employee Salary Prediction

A data cleaning, exploratory data analysis (EDA), and machine learning project that
predicts employee salary from HR attributes such as department, education level,
years of experience, and remote-work status, using **Linear Regression**.

## Project Overview

The raw dataset simulates real-world messy HR data — inconsistent text casing,
missing values, mixed date formats, and currency strings mixed with numbers.
This project walks through the full pipeline:

1. **Data Cleaning** — standardize text fields, impute missing values, fix invalid
   entries, and parse mixed date/currency formats.
2. **Exploratory Data Analysis** — univariate and bivariate visualizations to
   understand distributions and relationships between features and salary.
3. **Outlier Removal** — IQR-based filtering on the target variable.
4. **Feature Engineering** — categorical encoding and date decomposition.
5. **Model Training** — Linear Regression with a train/test split and feature scaling.
6. **Evaluation** — MAE, MSE, RMSE, and R² on the held-out test set.

## Repository Structure

```
.
├── employee_salary_prediction.ipynb   # Main notebook (cleaning → EDA → model)
├── data/
│   └── messy_salary_dataset.csv       # Raw input data (add your own copy here)
├── requirements.txt                   # Python dependencies
└── README.md
```

> **Note:** The raw CSV (`messy_salary_dataset.csv`) is not included in this repo.
> Place your copy in the `data/` folder before running the notebook, or update the
> file path in the "Load Dataset" cell.

## Dataset

Each row represents one employee, with the following columns:

| Column                  | Description                                  |
|--------------------------|-----------------------------------------------|
| `employee_id`            | Unique employee identifier                    |
| `age`                    | Employee age                                  |
| `gender`                 | Employee gender                               |
| `city`                   | City of employment                            |
| `department`             | Department (Engineering, Sales, HR, etc.)     |
| `education`               | Highest education level                       |
| `years_experience`       | Years of professional experience              |
| `hours_worked_per_week`  | Average hours worked per week                 |
| `remote_work`            | Whether the employee works remotely           |
| `date_joined`            | Date the employee joined the company          |
| `performance_score`      | Performance rating                            |
| `salary`                 | Annual salary (target variable)               |

## Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/<your-repo>.git
cd <your-repo>
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the notebook
```bash
jupyter notebook employee_salary_prediction.ipynb
```

## Model

- **Algorithm:** Linear Regression (scikit-learn)
- **Preprocessing:** `StandardScaler` fit on training data only (to avoid data leakage)
- **Feature selection:** Retained features with |correlation| ≥ 0.2 with the target
- **Evaluation metrics:** MAE, MSE, RMSE, R²

## Possible Extensions

- Compare against Ridge/Lasso regression or tree-based models (Random Forest, Gradient Boosting)
- Use one-hot encoding instead of category codes for nominal features
- Hyperparameter tuning via cross-validation
- Feature importance / coefficient interpretation

## License

This project is available under the MIT License.
